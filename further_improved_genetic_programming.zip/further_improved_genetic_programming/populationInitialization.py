from deap import creator, tools, gp
import psetHold
from toolBox import toolbox

def register_population(toolbox = toolbox):
    """注册个体和种群初始化操作"""

    pset = psetHold.psetHold()

    toolbox.register("expr", gp.genHalfAndHalf, pset=pset, min_=1, max_=2)
    toolbox.register("individual", tools.initIterate, creator.Individual, toolbox.expr)
    toolbox.register("population", tools.initRepeat, list, toolbox.individual)

    a = 1