import random
import numpy as np
from deap import base, creator, tools, gp, algorithms

#############################################################################
from populationInitialization import register_population
from optimizationTarget import create_fitness_and_individual
from breedingProcess import register_breeding_ops
from fitnessEvaluation import register_fitness_function
import readableFormula

import individualSimple

from toolBox import toolbox
#############################################################################


def main():

    random.seed(42)

    # ---------------------------------------
    # 1. 创建 Fitness 与 Individual 类型
    # ---------------------------------------
    create_fitness_and_individual()

    # ---------------------------------------
    # 2. 种群初始化
    # ---------------------------------------
    register_population()

    # ---------------------------------------
    # 3. 选择/交叉/变异操作
    # ---------------------------------------
    register_breeding_ops()

    # ---------------------------------------
    # 4. 注册适应度函数
    # ---------------------------------------
    register_fitness_function()

    # ---------------------------------------
    # 5. 运行 GP 算法
    # ---------------------------------------
    pop = toolbox.population(n=100)
    hof = tools.HallOfFame(1)

    stats = tools.Statistics(lambda ind: ind.fitness.values)
    stats.register("avg", np.mean)
    stats.register("min", np.min)

    pop, log = algorithms.eaSimple(
        pop,
        toolbox,
        cxpb=0.5,
        mutpb=0.2,
        ngen=100,
        stats=stats,
        halloffame=hof,
        verbose=True
    )


    print("\n===================")
    best = hof[0]
    print("\nBest individual:")
    print(best)
    # print("Fitness:", best.fitness.values[0])

    # 使用你的可读公式方法
    readable = readableFormula.tree_to_infix(best)
    print("\nReadable formula:")
    print(readable)

    simplified = individualSimple.simplify_individual_keep_type(best)
    print("\nSimplified Individual:")
    print( simplified)

    readable2 = readableFormula.tree_to_infix(simplified)
    print("\nReadable:")
    print(readable2)


if __name__ == "__main__":
    main()


