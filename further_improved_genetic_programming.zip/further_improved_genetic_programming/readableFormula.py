# readableFormula.py

# 对应 functionNodes 中函数名到数学符号或函数名的映射
op_map = {
    "add": "+",
    "sub": "-",
    "mul": "*",
    "div": "/",
    "sin": "sin",
    "cos": "cos",
    "sqrt": "sqrt",
    "ln": "ln",
    "neg": "-1*",
    "exp": "exp",
    "max": "max",
    "min": "min"
}

# 二元函数式运算，需要函数调用格式：max(a, b)
binary_func_names = {"max", "min"}

def tree_to_infix(tree, op_map = op_map):
    """
    将 DEAP 前缀树解析为中缀可读公式
    tree: DEAP Individual（PrimitiveTree）
    op_map: 函数名到符号/可读名的映射
    """
    it = iter(tree)

    def parse():
        node = next(it)
        name = op_map.get(node.name, node.name)

        # 终端（变量或常数）
        if node.arity == 0:
            return name

        # 一元函数
        elif node.arity == 1:
            arg = parse()
            # 对 neg 单独处理，显示为 -arg
            if node.name == "neg":
                return f"(-{arg})"
            return f"{name}({arg})"

        # 二元函数
        elif node.arity == 2:
            left = parse()
            right = parse()
            if node.name in binary_func_names:
                return f"{name}({left}, {right})"
            else:
                return f"({left} {name} {right})"

    return parse()
