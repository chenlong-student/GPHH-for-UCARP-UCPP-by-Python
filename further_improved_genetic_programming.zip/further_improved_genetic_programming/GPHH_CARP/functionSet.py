import functions
import configure_parameters

def function_set(pset):

    if pset is None:
        raise RuntimeError("Error: pSet.py文件中的pset变量是None，请检查你的terminalSet.py文件中是否成功赋值")

    ##function nodes:
    # 常见算术运算
    # if getattr(functions, configure_parameters.gpFunction_add) and configure_parameters.gpFunction_add:

    if configure_parameters.gpFunction_add is not None:
        pset.addPrimitive(functions.add, 2)
    if configure_parameters.gpFunction_sub is not None:
        pset.addPrimitive(functions.sub, 2)
    if configure_parameters.gpFunction_mul is not None:
        pset.addPrimitive(functions.mul, 2)
    if configure_parameters.gpFunction_div is not None:
        pset.addPrimitive(functions.div, 2)
    if configure_parameters.gpFunction_max is not None:
        pset.addPrimitive(functions.max, 2)
    if configure_parameters.gpFunction_min is not None:
        pset.addPrimitive(functions.min, 2)

    # 一元运算符
    if configure_parameters.gpFunction_sin is not None:
        pset.addPrimitive(functions.sin, 1)
    if configure_parameters.gpFunction_cos is not None:
        pset.addPrimitive(functions.cos, 1)
    if configure_parameters.gpFunction_exp is not None:
        pset.addPrimitive(functions.exp, 1)
    if configure_parameters.gpFunction_ln is not None:
        pset.addPrimitive(functions.ln, 1)
    if configure_parameters.gpFunction_neg is not None:
        pset.addPrimitive(functions.neg, 1)
    if configure_parameters.gpFunction_sqrt is not None:
        pset.addPrimitive(functions.sqrt, 1)
    if configure_parameters.gpFunction_abs is not None:
        pset.addPrimitive(functions.abs, 1)



    return pset