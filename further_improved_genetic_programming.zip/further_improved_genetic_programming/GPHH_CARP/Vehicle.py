

class Vehicle:
    def __init__(self, vehicle_count, capacity, start_depot):
        self.vehicle_count = vehicle_count
        self.capacity = capacity
        self.remain_capacity = capacity

        self.start_depot = start_depot
        self.end_depot = start_depot

        # 路径与成本
        self.path_nodes = [start_depot]   # 真实经过的节点序列
        self.total_cost = 0.0             # 完整回路累计成本

        # 已服务弧（用于 = / - 表达）
        self.served_arcs = []

        self.current_position = self.path_nodes[-1]

        self.current_cost = self.total_cost

        self.passed_path = ""

    # -------------------------------------------------
    # 路径与成本累积
    # -------------------------------------------------
    def add_move_path(self, path_nodes, cost):
        """
        path_nodes: [u, ..., v]（包含起点 u）
        """
        if len(path_nodes) > 1:
            self.path_nodes.extend(path_nodes[1:])
            self.total_cost += cost

    def add_service_arc(self, u, v, cost):
        self.path_nodes.append(v)
        self.total_cost += cost
        self.served_arcs.append((u, v))

    def finish_route(self, return_path, cost):
        if len(return_path) > 1:
            self.path_nodes.extend(return_path[1:])
            self.total_cost += cost
        self.end_depot = self.start_depot

    # -------------------------------------------------
    # 容量
    # -------------------------------------------------
    def use_capacity(self, demand):
        self.remain_capacity -= demand

    def reset_capacity(self):
        self.remain_capacity = self.capacity

    # -------------------------------------------------
    # 输出路径字符串
    # -------------------------------------------------
    def get_path_string(self):
        if len(self.path_nodes) <= 1:
            return str(self.start_depot)

        served = set(self.served_arcs)
        s = str(self.path_nodes[0])

        for i in range(len(self.path_nodes) - 1):
            u, v = self.path_nodes[i], self.path_nodes[i + 1]
            if (u, v) in served:
                s += f"={v}"
            else:
                s += f"-{v}"

        self.passed_path = s
        return s

    def __repr__(self):
        return (
            f"Vehicle(remain_capacity={self.remain_capacity}, "
            f"total_cost={self.total_cost:.2f}, "
            f"path={self.get_path_string()})"
        )
