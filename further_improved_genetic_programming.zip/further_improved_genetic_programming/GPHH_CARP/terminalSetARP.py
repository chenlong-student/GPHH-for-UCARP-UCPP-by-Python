from deap import gp
import terminalStateCARP
import configure_parameters

def terminal_set():
    if configure_parameters.problem == "CARP":
        return terminal_set_CARP()
    elif configure_parameters.problem == "CPP":
        return terminal_set_CPP()
    elif configure_parameters.problem == "RPP":
        return terminal_set_RPP()
    elif configure_parameters.problem == "kRPP":
        return terminal_set_kRPP()


def terminal_set_CARP():

    # 创建 4 个输入变量
    pset = gp.PrimitiveSet("MAIN", 0)

    ##CFH: cost from here
    if configure_parameters.gpTerminal_CFH is not None:
        pset.addTerminal(terminalStateCARP.CFH(), name="CFH")

    ##CFD: cost from the arc to the depot
    if configure_parameters.gpTerminal_CFD is not None:
        pset.addTerminal(terminalStateCARP.CFD(), name="CFD")

    ##CFR1: cost from other routes to the candidate task
    if configure_parameters.gpTerminal_CFR1 is not None:
        pset.addTerminal(terminalStateCARP.CFR1(), name="CFR1")

    # CTT1：候选弧终点 → 其他未服务弧起点的最小距离
    if configure_parameters.gpTerminal_CTT1 is not None:
        pset.addTerminal(terminalStateCARP.CTT1(), name="CTT1")

    ##CTD: cost from the depot to the candidate task
    if configure_parameters.gpTerminal_CTD is not None:
        pset.addTerminal(terminalStateCARP.CTD(), name="CTD")

    ##CR: cost from the depot to the current location
    if configure_parameters.gpTerminal_CR is not None:
        pset.addTerminal(terminalStateCARP.CR(), name="CR")

    ##DEM: demand of the candidate task
    if configure_parameters.gpTerminal_DEM is not None:
        pset.addTerminal(terminalStateCARP.DEM(), name="DEM")

    ##DEM1: demand of the closest unserved task to the candidate task
    if configure_parameters.gpTerminal_DEM1 is not None:
        pset.addTerminal(terminalStateCARP.DEM1(), name="DEM1")

    ##DC: deadheading cost of the candidate task
    if configure_parameters.gpTerminal_DC is not None:
        pset.addTerminal(terminalStateCARP.DC(), name="DC")

    ##FULL: fullness of the vehicle
    if configure_parameters.gpTerminal_FULL is not None:
        pset.addTerminal(terminalStateCARP.FULL(), name="FULL")

    ##FRT: fraction of the unserved tasks
    if configure_parameters.gpTerminal_FRT is not None:
        pset.addTerminal(terminalStateCARP.FRT(), name="FRT")

    ##FUT
    if configure_parameters.gpTerminal_FUT is not None:
        pset.addTerminal(terminalStateCARP.FUT(), name="FUT")

    ##RQ: the demand left
    if configure_parameters.gpTerminal_RQ is not None:
        pset.addTerminal(terminalStateCARP.RQ(), name="RQ")

    ##RQ1: remaining capacity of the closest alternative route
    if configure_parameters.gpTerminal_RQ1 is not None:
        pset.addTerminal(terminalStateCARP.RQ1(), name="RQ1")

    ##SC: 弧的走形成本
    if configure_parameters.gpTerminal_SC is not None and terminalStateCARP.SC() is not None:
        pset.addTerminal(terminalStateCARP.SC(), name="SC")

    ##ERC: 随机值
    if configure_parameters.gpTerminal_ERC is not None and terminalStateCARP.ERC() is not None:
        pset.addTerminal(terminalStateCARP.ERC(), name="ERC")

    return pset

def terminal_set_CPP():
    # 创建 4 个输入变量
    pset = gp.PrimitiveSet("MAIN", 0)

    ##CFH: cost from here
    if configure_parameters.gpTerminal_CFH is not None:
        pset.addTerminal(terminalStateCARP.CFH(), name="CFH")

    ##CFD: cost from the arc to the depot
    if configure_parameters.gpTerminal_CFD is not None:
        pset.addTerminal(terminalStateCARP.CFD(), name="CFD")

    # ##CFR1: cost from other routes to the candidate task
    # if configure_parameters.gpTerminal_CFR1 is not None:
    #     pset.addTerminal(terminalStateCARP.CFR1(), name="CFR1")

    # CTT1：候选弧终点 → 其他未服务弧起点的最小距离
    if configure_parameters.gpTerminal_CTT1 is not None:
        pset.addTerminal(terminalStateCARP.CTT1(), name="CTT1")

    ##CTD: cost from the depot to the candidate task
    if configure_parameters.gpTerminal_CTD is not None:
        pset.addTerminal(terminalStateCARP.CTD(), name="CTD")

    ##CR: cost from the depot to the current location
    if configure_parameters.gpTerminal_CR is not None:
        pset.addTerminal(terminalStateCARP.CR(), name="CR")

    # ##DEM: demand of the candidate task
    # if configure_parameters.gpTerminal_DEM is not None:
    #     pset.addTerminal(terminalStateCARP.DEM(), name="DEM")

    # ##DEM1: demand of the closest unserved task to the candidate task
    # if configure_parameters.gpTerminal_DEM1 is not None:
    #     pset.addTerminal(terminalStateCARP.DEM1(), name="DEM1")

    ##DC: deadheading cost of the candidate task
    if configure_parameters.gpTerminal_DC is not None:
        pset.addTerminal(terminalStateCARP.DC(), name="DC")

    # ##FULL: fullness of the vehicle
    # if configure_parameters.gpTerminal_FULL is not None:
    #     pset.addTerminal(terminalStateCARP.FULL(), name="FULL")

    ##FRT: fraction of the unserved tasks
    if configure_parameters.gpTerminal_FRT is not None:
        pset.addTerminal(terminalStateCARP.FRT(), name="FRT")

    ##FUT
    if configure_parameters.gpTerminal_FUT is not None:
        pset.addTerminal(terminalStateCARP.FUT(), name="FUT")

    # ##RQ: the demand left
    # if configure_parameters.gpTerminal_RQ is not None:
    #     pset.addTerminal(terminalStateCARP.RQ(), name="RQ")

    # ##RQ1: remaining capacity of the closest alternative route
    # if configure_parameters.gpTerminal_RQ1 is not None:
    #     pset.addTerminal(terminalStateCARP.RQ1(), name="RQ1")

    ##SC: 弧的走形成本
    if configure_parameters.gpTerminal_SC is not None and terminalStateCARP.SC() is not None:
        pset.addTerminal(terminalStateCARP.SC(), name="SC")

    ##ERC: 随机值
    if configure_parameters.gpTerminal_ERC is not None and terminalStateCARP.ERC() is not None:
        pset.addTerminal(terminalStateCARP.ERC(), name="ERC")

    return pset

def terminal_set_RPP():
    # 创建 4 个输入变量
    pset = gp.PrimitiveSet("MAIN", 0)

    ##CFH: cost from here
    if configure_parameters.gpTerminal_CFH is not None:
        pset.addTerminal(terminalStateCARP.CFH(), name="CFH")

    ##CFD: cost from the arc to the depot
    if configure_parameters.gpTerminal_CFD is not None:
        pset.addTerminal(terminalStateCARP.CFD(), name="CFD")

    # ##CFR1: cost from other routes to the candidate task
    # if configure_parameters.gpTerminal_CFR1 is not None:
    #     pset.addTerminal(terminalStateCARP.CFR1(), name="CFR1")

    # CTT1：候选弧终点 → 其他未服务弧起点的最小距离
    if configure_parameters.gpTerminal_CTT1 is not None:
        pset.addTerminal(terminalStateCARP.CTT1(), name="CTT1")

    ##CTD: cost from the depot to the candidate task
    if configure_parameters.gpTerminal_CTD is not None:
        pset.addTerminal(terminalStateCARP.CTD(), name="CTD")

    ##CR: cost from the depot to the current location
    if configure_parameters.gpTerminal_CR is not None:
        pset.addTerminal(terminalStateCARP.CR(), name="CR")

    # ##DEM: demand of the candidate task
    # if configure_parameters.gpTerminal_DEM is not None:
    #     pset.addTerminal(terminalStateCARP.DEM(), name="DEM")

    # ##DEM1: demand of the closest unserved task to the candidate task
    # if configure_parameters.gpTerminal_DEM1 is not None:
    #     pset.addTerminal(terminalStateCARP.DEM1(), name="DEM1")

    ##DC: deadheading cost of the candidate task
    if configure_parameters.gpTerminal_DC is not None:
        pset.addTerminal(terminalStateCARP.DC(), name="DC")

    # ##FULL: fullness of the vehicle
    # if configure_parameters.gpTerminal_FULL is not None:
    #     pset.addTerminal(terminalStateCARP.FULL(), name="FULL")

    ##FRT: fraction of the unserved tasks
    if configure_parameters.gpTerminal_FRT is not None:
        pset.addTerminal(terminalStateCARP.FRT(), name="FRT")

    ##FUT
    if configure_parameters.gpTerminal_FUT is not None:
        pset.addTerminal(terminalStateCARP.FUT(), name="FUT")

    # ##RQ: the demand left
    # if configure_parameters.gpTerminal_RQ is not None:
    #     pset.addTerminal(terminalStateCARP.RQ(), name="RQ")

    # ##RQ1: remaining capacity of the closest alternative route
    # if configure_parameters.gpTerminal_RQ1 is not None:
    #     pset.addTerminal(terminalStateCARP.RQ1(), name="RQ1")

    ##SC: 弧的走形成本
    if configure_parameters.gpTerminal_SC is not None and terminalStateCARP.SC() is not None:
        pset.addTerminal(terminalStateCARP.SC(), name="SC")

    ##ERC: 随机值
    if configure_parameters.gpTerminal_ERC is not None and terminalStateCARP.ERC() is not None:
        pset.addTerminal(terminalStateCARP.ERC(), name="ERC")

    return pset


def terminal_set_kRPP():

    # 创建 4 个输入变量
    pset = gp.PrimitiveSet("MAIN", 0)

    ##CFH: cost from here
    if configure_parameters.gpTerminal_CFH is not None:
        pset.addTerminal(terminalStateCARP.CFH(), name="CFH")

    ##CFD: cost from the arc to the depot
    if configure_parameters.gpTerminal_CFD is not None:
        pset.addTerminal(terminalStateCARP.CFD(), name="CFD")

    ##CFR1: cost from other routes to the candidate task
    if configure_parameters.gpTerminal_CFR1 is not None:
        pset.addTerminal(terminalStateCARP.CFR1(), name="CFR1")

    # CTT1：候选弧终点 → 其他未服务弧起点的最小距离
    if configure_parameters.gpTerminal_CTT1 is not None:
        pset.addTerminal(terminalStateCARP.CTT1(), name="CTT1")

    ##CTD: cost from the depot to the candidate task
    if configure_parameters.gpTerminal_CTD is not None:
        pset.addTerminal(terminalStateCARP.CTD(), name="CTD")

    ##CR: cost from the depot to the current location
    if configure_parameters.gpTerminal_CR is not None:
        pset.addTerminal(terminalStateCARP.CR(), name="CR")

    # ##DEM: demand of the candidate task
    # if configure_parameters.gpTerminal_DEM is not None:
    #     pset.addTerminal(terminalStateCARP.DEM(), name="DEM")

    # ##DEM1: demand of the closest unserved task to the candidate task
    # if configure_parameters.gpTerminal_DEM1 is not None:
    #     pset.addTerminal(terminalStateCARP.DEM1(), name="DEM1")

    ##DC: deadheading cost of the candidate task
    if configure_parameters.gpTerminal_DC is not None:
        pset.addTerminal(terminalStateCARP.DC(), name="DC")

    # ##FULL: fullness of the vehicle
    # if configure_parameters.gpTerminal_FULL is not None:
    #     pset.addTerminal(terminalStateCARP.FULL(), name="FULL")

    ##FRT: fraction of the unserved tasks
    if configure_parameters.gpTerminal_FRT is not None:
        pset.addTerminal(terminalStateCARP.FRT(), name="FRT")

    ##FUT
    if configure_parameters.gpTerminal_FUT is not None:
        pset.addTerminal(terminalStateCARP.FUT(), name="FUT")

    # ##RQ: the demand left
    # if configure_parameters.gpTerminal_RQ is not None:
    #     pset.addTerminal(terminalStateCARP.RQ(), name="RQ")

    # ##RQ1: remaining capacity of the closest alternative route
    # if configure_parameters.gpTerminal_RQ1 is not None:
    #     pset.addTerminal(terminalStateCARP.RQ1(), name="RQ1")

    ##SC: 弧的走形成本
    if configure_parameters.gpTerminal_SC is not None and terminalStateCARP.SC() is not None:
        pset.addTerminal(terminalStateCARP.SC(), name="SC")

    ##ERC: 随机值
    if configure_parameters.gpTerminal_ERC is not None and terminalStateCARP.ERC() is not None:
        pset.addTerminal(terminalStateCARP.ERC(), name="ERC")

    return pset

