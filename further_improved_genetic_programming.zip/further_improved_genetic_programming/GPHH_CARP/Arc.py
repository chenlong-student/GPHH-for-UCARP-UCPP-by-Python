from copy import deepcopy

import numpy as np
import configure_parameters

class Arc:
    def __init__(self, start_vertex, end_vertex, demanda, coste):
        self.start_vertex = start_vertex
        self.end_vertex = end_vertex
        self.coste = coste
        self.demanda = demanda
        self.coste_original = coste
        self.demanda_original = demanda

        self.reverse_arc = None

    def set_reverse(self, reverse_arc):
        self.reverse_arc = reverse_arc


    def randomize(self, seed=None):
        if seed is not None:
            np.random.seed(seed)

        # #同时更新正向弧和反向弧
        if self.demanda_original > 0:
            try:
                new_demanda = int(np.random.normal(self.demanda_original, self.demanda_original * configure_parameters.demand_change_rate))
            except OverflowError:
                new_demanda = self.demanda_original  # 或者直接设为一个合理值
            new_demanda = max(1, new_demanda)
        else:
            new_demanda = 0

        try:
            new_coste = int(np.random.normal(self.coste_original, self.coste_original * configure_parameters.cost_change_rate))
        except OverflowError:
            new_coste = self.coste_original  # 或者直接设为一个合理值
        new_coste = max(1, new_coste)


        self.demanda = new_demanda
        self.coste = new_coste

        if self.reverse_arc:
            self.reverse_arc.demanda = self.demanda
            self.reverse_arc.coste = self.coste

    def __repr__(self):
        return f"({self.start_vertex}->{self.end_vertex}, demanda={self.demanda}, coste={self.coste})"

    def __eq__(self, other):
        return isinstance(other, Arc) and \
            self.start_vertex == other.start_vertex and \
            self.end_vertex == other.end_vertex and \
            self.demanda == other.demanda and \
            self.coste == other.coste

    def __hash__(self):
        return hash((self.start_vertex, self.end_vertex, self.demanda, self.coste))

    def copy(self):
        """返回一个独立的 Arc 副本（不共享 reverse_arc）"""
        new_arc = Arc(self.start_vertex, self.end_vertex, self.demanda, self.coste)

        new_arc.coste_original = self.coste_original
        new_arc.demanda_original = self.demanda_original
        new_arc.reverse_arc = self.reverse_arc
        # 注意 reverse_arc 需要在创建 pair 时再关联，不在这里复制
        return new_arc