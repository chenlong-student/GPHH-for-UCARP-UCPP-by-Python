##数据集使用:they can be download in https://www.uv.es/belengue/carp.html

problem = "kRPP" ## "CPP" or "RPP" or "kRPP" or "CARP"

# data_path = f"data_{problem}/kshs/kshs1.dat"
data_path = f"data_{problem}/gdb/gdb1.dat"
# data_path = f"data_{problem}/val/val1A.dat"
# data_path = f"data_{problem}/egl/egl-e1-B.dat"

##随机种子
seed = 0

##instance中需求扰动幅度
demand_change_rate = 0.20
##instance中里程扰动幅度
cost_change_rate = 0.20

##目标函数类型
fitnessType = 'MIN' ##or 'MAX'

##演化次数
gen = 50   ## 50

##种群初始化
##种群规模
population_size = 100  ##1024
##种群初始化方式
population_generation_way = "genHalfAndHalf"   ## "genFull" or "genGrow"
##初始化最小深度和最大深度
min_depth_initial = 1 ##2
max_depth_initial = 7 ##8
##避免种群出现 “重复个体｜树木的最大深度” 的最大尝试次数
max_attempts_unique = 10

##种群繁衍
##父代选择方式
selection_way = "selTournament" ## or "selBest"
##锦标赛选择前7个
tourn_size = 7  ##7
##产生新子树的最小深度和最大深度
min_depth_new_subtree = 1 ## 2
max_depth_new_subtree = 3 ## 8
##限制树的最大深度
max_depth_mutate = 7    ##8
max_depth_mate = 7      ##8
max_depth_reproduct = 7 ##8
##变异概率
mutate_probability = 0.18
##交叉概率
crossover_probability = 0.80
##重复概率
reproduct_probability = 0.02
##精英个体数量
elitism_size = 10  ##10
##精英个体挑选时的适应度存活半径
elitism_radius = 0.08 ##0

##gphh节点设置
##gphh_terminals: you can set them in "State.py" and use them in "terminalStateCARP.py" and "terminalSetARP.py"
gpTerminal_CFH = " " ##or None
gpTerminal_CFD = " "
gpTerminal_CFR1 = " "
gpTerminal_CTT1 = " "
gpTerminal_CTD = " "
gpTerminal_CR = " "
gpTerminal_DEM = " "
gpTerminal_DEM1 = " "
gpTerminal_DC = " "
gpTerminal_FULL = " "
gpTerminal_FRT = " "
gpTerminal_FUT = " "
gpTerminal_RQ = " "
gpTerminal_RQ1 = " "
gpTerminal_SC = " "
gpTerminal_ERC = " "

##gphh_functions: you can set them in "functions.py" and use them in "functionSet.py"
# if you don't want to ues this function: "gpFunction_add = None"
gpFunction_add = " " ## or None
gpFunction_sub = " "
gpFunction_mul = " "
gpFunction_div = " "
gpFunction_max = " "
gpFunction_min = " "
gpFunction_sin = None
gpFunction_cos = None
gpFunction_exp = None
gpFunction_ln = None
gpFunction_neg = None
gpFunction_sqrt = None
gpFunction_abs = None

##batch_learning
batch_learning_num = 5 ## 5



##每多少轮最优个体不变时更新一次种群
update_population_times = 5
