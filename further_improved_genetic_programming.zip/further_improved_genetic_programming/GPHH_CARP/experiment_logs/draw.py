import pandas as pd
import matplotlib.pyplot as plt
from matplotlib.font_manager import FontProperties
import os

# =====================================================
# 1. 准备数据（与你给的表一致）
# =====================================================
data = pd.read_excel("/Users/chenlong/Desktop/1.9编码表.xlsx")

df = data

# =====================================================
# 2. 设置 macOS 中文字体（自动找真实存在路径）
# =====================================================
def get_chinese_font():
    paths = [
        "/System/Library/Fonts/Supplemental/Arial Unicode.ttf",
        "/System/Library/Fonts/Supplemental/Songti.ttc",
        "/System/Library/Fonts/Supplemental/STHeiti Medium.ttc",
        "/Library/Fonts/Arial Unicode.ttf"
    ]
    for p in paths:
        if os.path.exists(p):
            return FontProperties(fname=p)
    return None

chinese_font = get_chinese_font()

# =====================================================
# 3. 绘制折线图
# =====================================================
fig, ax = plt.subplots(figsize=(12, 6), constrained_layout=True)

# x 轴改成中文月份
x = df["月份"].astype(str)

fig, ax = plt.subplots(figsize=(12, 6), constrained_layout=True)

for col in df.columns[1:]:
    ax.plot(x, df[col] * 100, marker="o", linewidth=2, label=col)

if chinese_font:
    ax.set_xlabel("月份", fontproperties=chinese_font)
    ax.set_ylabel("占比（%）", fontproperties=chinese_font)
    ax.set_title("不同媒体月度报道占比变化趋势", fontproperties=chinese_font)
    ax.legend(prop=chinese_font)
    ax.tick_params(axis='x', labelrotation=0)  # x轴刻度旋转
    ax.set_xticks(range(len(x)))               # 设置刻度位置
    ax.set_xticklabels(x, fontproperties=chinese_font)  # 设置刻度字体
else:
    ax.set_xlabel("月份")
    ax.set_ylabel("占比（%）")
    ax.set_title("不同媒体月度报道占比变化趋势")
    ax.legend()
    ax.set_xticklabels(x)

ax.grid(False)
plt.show()

