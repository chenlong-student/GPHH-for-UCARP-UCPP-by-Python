import math


def add(a, b):
    return a + b

def sub(a, b):
    return a - b

def mul(a, b):
    return a * b

def div(a, b):
    if b != 0:
        return a / b
    else:
        return 1.0

def max(a, b):
    if a > b:
        return a
    else:
        return b

def min(a, b):
    if a < b:
        return a
    else:
        return b

def sin(a):
    try:
        return math.sin(a)
    except:
        return 1.0

def cos(a):
    try:
        return math.cos(a)
    except:
        return 1.0

def exp(a):
    try:
        return math.exp(a)
    except:
        return 1.0

def ln(a):
    try:
        return math.log(a)
    except:
        return 1.0

def neg(a):
    return -1*a

def sqrt(a):
    try:
        return math.sqrt(a)
    except:
        return 1.0

def abs(a):
    return math.fabs(a)
