from deap import gp
import configure_parameters
import functions
import random


_TERMINAL_INDEX = {
    "CFH": 0,
    "CFD": 1,
    "CFR1": 2,
    "CTT1": 3,
    "CTD": 4,
    "CR": 5,
    "DEM": 6,
    "DEM1": 7,
    "DC": 8,
    "FULL": 9,
    "FRT": 10,
    "FUT": 11,
    "RQ": 12,
    "RQ1": 13,
    "SC": 14,
    "ERC": 15,
}

_PRIMITIVE_FUNC = {
    "add": functions.add,
    "sub": functions.sub,
    "mul": functions.mul,
    "div": functions.div,
    "max": functions.max,
    "min": functions.min,
    "sin": functions.sin,
    "cos": functions.cos,
    "exp": functions.exp,
    "ln": functions.ln,
    "neg": functions.neg,
    "sqrt": functions.sqrt,
    "abs": functions.abs,
}


def _individual_signature(individual):
    signature = getattr(individual, "_fast_eval_signature", None)
    current_signature = str(individual)
    if signature != current_signature:
        individual._fast_eval_signature = current_signature
        individual._fast_eval_program = None
    return current_signature


def _compile_program(individual):
    current_signature = _individual_signature(individual)
    cached_program = getattr(individual, "_fast_eval_program", None)
    if cached_program is not None:
        return cached_program

    def walk(index):
        node = individual[index]
        cursor = index + 1
        program = []

        if isinstance(node, gp.Primitive):
            for _ in range(node.arity):
                child_program, cursor = walk(cursor)
                program.extend(child_program)
            program.append(("prim", _PRIMITIVE_FUNC[node.name], node.arity))
            return program, cursor

        node_name = getattr(node, "name", None)
        if node_name in _TERMINAL_INDEX:
            program.append(("term", _TERMINAL_INDEX[node_name]))
            return program, cursor

        value = getattr(node, "value", node)
        if callable(value):
            raise TypeError(f"Unsupported callable terminal: {node_name}")
        program.append(("const", float(value)))
        return program, cursor

    program, next_index = walk(0)
    if next_index != len(individual):
        raise ValueError("Failed to compile the full GP tree")

    individual._fast_eval_signature = current_signature
    individual._fast_eval_program = tuple(program)
    return individual._fast_eval_program


def _execute_program(program, context):
    stack = []
    for instruction in program:
        op_type = instruction[0]
        if op_type == "const":
            stack.append(instruction[1])
            continue
        if op_type == "term":
            stack.append(context[instruction[1]])
            continue

        func = instruction[1]
        arity = instruction[2]
        if arity == 1:
            stack.append(func(stack.pop()))
            continue

        right = stack.pop()
        left = stack.pop()
        stack.append(func(left, right))

    return stack[-1]


def _build_reverse_index(required_arcs):
    arc_key_to_indices = {}
    for idx, arc in enumerate(required_arcs):
        key = (arc.start_vertex, arc.end_vertex, arc.demanda, arc.coste)
        arc_key_to_indices.setdefault(key, []).append(idx)

    reverse_index = []
    for idx, arc in enumerate(required_arcs):
        reverse_key = (
            arc.end_vertex,
            arc.start_vertex,
            getattr(arc.reverse_arc, "demanda", arc.demanda),
            getattr(arc.reverse_arc, "coste", arc.coste),
        )
        candidates = arc_key_to_indices.get(reverse_key)
        if not candidates:
            raise KeyError(
                f"Cannot locate reverse arc for ({arc.start_vertex}->{arc.end_vertex}, "
                f"demand={arc.demanda}, cost={arc.coste})"
            )
        reverse_idx = next((candidate for candidate in candidates if candidate != idx), candidates[0])
        reverse_index.append(reverse_idx)

    return tuple(reverse_index)


def _build_inter_arc_distance(start_vertices, end_vertices, od):
    count = len(start_vertices)
    return tuple(
        tuple(od[end_vertices[i]][start_vertices[j]] for j in range(count))
        for i in range(count)
    )


def _get_seed_meta(instance):
    meta = getattr(instance, "_fast_eval_meta", None)
    if meta is not None:
        return meta

    required_arcs = tuple(instance.seed_requiredArc)
    start_vertices = tuple(arc.start_vertex for arc in required_arcs)
    end_vertices = tuple(arc.end_vertex for arc in required_arcs)
    demands = tuple(getattr(arc, "demanda", 0.0) for arc in required_arcs)
    costs = tuple(arc.coste for arc in required_arcs)
    od_original = instance.originalGraphConnected
    depot = instance.deposito

    meta = {
        "required_arcs": required_arcs,
        "reverse_index": _build_reverse_index(required_arcs),
        "start_vertices": start_vertices,
        "end_vertices": end_vertices,
        "demands": demands,
        "costs": costs,
        "arc_to_depot": tuple(od_original[end_vertex][depot] for end_vertex in end_vertices),
        "depot_to_arc": tuple(od_original[depot][start_vertex] for start_vertex in start_vertices),
        "deadheading": tuple(od_original[start][end] for start, end in zip(start_vertices, end_vertices)),
        "inter_arc_distance": _build_inter_arc_distance(start_vertices, end_vertices, od_original),
        "vehicle_capacity": tuple(vehicle.capacity for vehicle in instance.vehicles),
        "vehicle_positions": tuple(vehicle.current_position for vehicle in instance.vehicles),
        "vehicle_costs": tuple(vehicle.total_cost for vehicle in instance.vehicles),
        "vehicle_remaining": tuple(getattr(vehicle, "remain_capacity", vehicle.capacity) for vehicle in instance.vehicles),
        "depot": depot,
        "od_original": od_original,
        "od_seed": instance.seedGraphConnected,
        "seed_edges_count": len(instance.seedEdges),
    }
    instance._fast_eval_meta = meta
    return meta


def _active_state(count):
    return list(range(count)), list(range(count))


def _remove_active_arc(active_arcs, active_pos, arc_idx):
    pos = active_pos[arc_idx]
    if pos == -1:
        return

    last_idx = active_arcs.pop()
    active_pos[arc_idx] = -1
    if pos == len(active_arcs):
        return

    active_arcs[pos] = last_idx
    active_pos[last_idx] = pos


def _compute_vehicle_route_features_inplace(route_costs, current_positions, od):
    vehicle_count = len(current_positions)
    for i in range(vehicle_count):
        pos_i = current_positions[i]
        best = float("inf")
        for j in range(vehicle_count):
            if i == j:
                continue
            dist = od[current_positions[j]][pos_i]
            if dist < best:
                best = dist
        route_costs[i] = best if best != float("inf") else 1.0


def _compute_arc_features_inplace(dem1, ctt1, active_arcs, demands, inter_arc_distance):
    for arc_idx in active_arcs:
        best_dem_dist = float("inf")
        best_ctt_dist = float("inf")
        row = inter_arc_distance[arc_idx]
        best_dem = 1.0
        best_ctt = 1.0

        for other_idx in active_arcs:
            if other_idx == arc_idx:
                continue

            ctt_dist = row[other_idx]
            if ctt_dist < best_ctt_dist:
                best_ctt_dist = ctt_dist
                best_ctt = ctt_dist

            dem_dist = inter_arc_distance[other_idx][arc_idx]
            if dem_dist < best_dem_dist:
                best_dem_dist = dem_dist
                best_dem = demands[other_idx]

        dem1[arc_idx] = best_dem
        ctt1[arc_idx] = best_ctt


def _select_best_candidate_CARP(program, meta, active_arcs, current_positions, remaining_capacity, rng, route_costs, dem1, ctt1):
    od = meta["od_original"]
    depot = meta["depot"]
    capacities = meta["vehicle_capacity"]
    total_seed_edges = meta["seed_edges_count"]
    start_vertices = meta["start_vertices"]
    demands = meta["demands"]
    costs = meta["costs"]
    arc_to_depot = meta["arc_to_depot"]
    depot_to_arc = meta["depot_to_arc"]
    deadheading = meta["deadheading"]

    _compute_vehicle_route_features_inplace(route_costs, current_positions, od)
    _compute_arc_features_inplace(dem1, ctt1, active_arcs, demands, meta["inter_arc_distance"])

    task_count = len(active_arcs)
    frt = task_count * total_seed_edges
    fut = (task_count - 1) * total_seed_edges

    best_value = None
    best_candidates = []
    context = [1.0] * 16

    for vehicle_idx, vehicle_pos in enumerate(current_positions):
        context[_TERMINAL_INDEX["CFR1"]] = route_costs[vehicle_idx]
        context[_TERMINAL_INDEX["CR"]] = od[depot][vehicle_pos]
        context[_TERMINAL_INDEX["FULL"]] = capacities[vehicle_idx]
        context[_TERMINAL_INDEX["FRT"]] = frt
        context[_TERMINAL_INDEX["FUT"]] = fut
        context[_TERMINAL_INDEX["RQ"]] = remaining_capacity[vehicle_idx]
        context[_TERMINAL_INDEX["RQ1"]] = remaining_capacity[vehicle_idx]

        od_vehicle = od[vehicle_pos]
        for arc_idx in active_arcs:
            context[_TERMINAL_INDEX["CFH"]] = od_vehicle[start_vertices[arc_idx]]
            context[_TERMINAL_INDEX["CFD"]] = arc_to_depot[arc_idx]
            context[_TERMINAL_INDEX["CTT1"]] = ctt1[arc_idx]
            context[_TERMINAL_INDEX["CTD"]] = depot_to_arc[arc_idx]
            context[_TERMINAL_INDEX["DEM"]] = demands[arc_idx]
            context[_TERMINAL_INDEX["DEM1"]] = dem1[arc_idx]
            context[_TERMINAL_INDEX["DC"]] = deadheading[arc_idx]
            context[_TERMINAL_INDEX["SC"]] = costs[arc_idx]
            context[_TERMINAL_INDEX["ERC"]] = rng.random()

            value = _execute_program(program, context)
            candidate = (vehicle_idx, arc_idx)

            if best_value is None:
                best_value = value
                best_candidates = [candidate]
            elif configure_parameters.fitnessType == "MIN":
                if value < best_value:
                    best_value = value
                    best_candidates = [candidate]
                elif value == best_value:
                    best_candidates.append(candidate)
            else:
                if value > best_value:
                    best_value = value
                    best_candidates = [candidate]
                elif value == best_value:
                    best_candidates.append(candidate)

    return rng.choice(best_candidates)


def _select_best_candidate_CPP(program, meta, active_arcs, current_positions, rng, route_costs, ctt1):
    od = meta["od_original"]
    depot = meta["depot"]
    total_seed_edges = meta["seed_edges_count"]
    start_vertices = meta["start_vertices"]
    costs = meta["costs"]
    arc_to_depot = meta["arc_to_depot"]
    depot_to_arc = meta["depot_to_arc"]
    deadheading = meta["deadheading"]

    _compute_vehicle_route_features_inplace(route_costs, current_positions, od)
    _compute_arc_features_inplace([1.0] * len(meta["required_arcs"]), ctt1, active_arcs, meta["demands"], meta["inter_arc_distance"])

    task_count = len(active_arcs)
    frt = task_count * total_seed_edges
    fut = (task_count - 1) * total_seed_edges

    best_value = None
    best_candidates = []
    context = [1.0] * 16

    for vehicle_idx, vehicle_pos in enumerate(current_positions):
        context[_TERMINAL_INDEX["CFR1"]] = route_costs[vehicle_idx]
        context[_TERMINAL_INDEX["CR"]] = od[depot][vehicle_pos]
        context[_TERMINAL_INDEX["FRT"]] = frt
        context[_TERMINAL_INDEX["FUT"]] = fut

        od_vehicle = od[vehicle_pos]
        for arc_idx in active_arcs:
            context[_TERMINAL_INDEX["CFH"]] = od_vehicle[start_vertices[arc_idx]]
            context[_TERMINAL_INDEX["CFD"]] = arc_to_depot[arc_idx]
            context[_TERMINAL_INDEX["CTT1"]] = ctt1[arc_idx]
            context[_TERMINAL_INDEX["CTD"]] = depot_to_arc[arc_idx]
            context[_TERMINAL_INDEX["DC"]] = deadheading[arc_idx]
            context[_TERMINAL_INDEX["SC"]] = costs[arc_idx]
            context[_TERMINAL_INDEX["ERC"]] = rng.random()

            value = _execute_program(program, context)
            candidate = (vehicle_idx, arc_idx)

            if best_value is None:
                best_value = value
                best_candidates = [candidate]
            elif configure_parameters.fitnessType == "MIN":
                if value < best_value:
                    best_value = value
                    best_candidates = [candidate]
                elif value == best_value:
                    best_candidates.append(candidate)
            else:
                if value > best_value:
                    best_value = value
                    best_candidates = [candidate]
                elif value == best_value:
                    best_candidates.append(candidate)

    return rng.choice(best_candidates)


def evaluate_individual_CARP(individual, instance):
    program = _compile_program(individual)
    meta = _get_seed_meta(instance)
    rng = random.Random(instance.seed)

    current_positions = list(meta["vehicle_positions"])
    remaining_capacity = list(meta["vehicle_remaining"])
    total_costs = list(meta["vehicle_costs"])
    active_arcs, active_pos = _active_state(len(meta["required_arcs"]))
    route_costs = [1.0] * len(current_positions)
    dem1 = [1.0] * len(meta["required_arcs"])
    ctt1 = [1.0] * len(meta["required_arcs"])

    depot = meta["depot"]
    od_seed = meta["od_seed"]
    start_vertices = meta["start_vertices"]
    end_vertices = meta["end_vertices"]
    demands = meta["demands"]
    service_costs = meta["costs"]
    capacities = meta["vehicle_capacity"]
    reverse_index = meta["reverse_index"]

    while active_arcs:
        vehicle_idx, arc_idx = _select_best_candidate_CARP(
            program, meta, active_arcs, current_positions, remaining_capacity, rng, route_costs, dem1, ctt1
        )

        curr_pos = current_positions[vehicle_idx]
        target_start = start_vertices[arc_idx]
        demand = demands[arc_idx]

        if remaining_capacity[vehicle_idx] < demand:
            if curr_pos != depot:
                total_costs[vehicle_idx] += od_seed[curr_pos][depot]
            remaining_capacity[vehicle_idx] = capacities[vehicle_idx]
            curr_pos = depot
            if curr_pos != target_start:
                total_costs[vehicle_idx] += od_seed[depot][target_start]
        elif curr_pos != target_start:
            total_costs[vehicle_idx] += od_seed[curr_pos][target_start]

        remaining_capacity[vehicle_idx] -= demand
        total_costs[vehicle_idx] += service_costs[arc_idx]
        current_positions[vehicle_idx] = end_vertices[arc_idx]

        _remove_active_arc(active_arcs, active_pos, arc_idx)
        _remove_active_arc(active_arcs, active_pos, reverse_index[arc_idx])

    total_fitness = 0.0
    for vehicle_idx, pos in enumerate(current_positions):
        if pos != depot:
            total_costs[vehicle_idx] += od_seed[pos][depot]
        total_fitness += total_costs[vehicle_idx]

    individual.fitness = total_fitness
    return individual


def evaluate_individual_CPP(individual, instance):
    program = _compile_program(individual)
    meta = _get_seed_meta(instance)
    rng = random.Random(instance.seed)

    current_positions = list(meta["vehicle_positions"])
    total_costs = list(meta["vehicle_costs"])
    active_arcs, active_pos = _active_state(len(meta["required_arcs"]))
    route_costs = [1.0] * len(current_positions)
    ctt1 = [1.0] * len(meta["required_arcs"])

    depot = meta["depot"]
    od_seed = meta["od_seed"]
    start_vertices = meta["start_vertices"]
    end_vertices = meta["end_vertices"]
    service_costs = meta["costs"]
    reverse_index = meta["reverse_index"]

    while active_arcs:
        vehicle_idx, arc_idx = _select_best_candidate_CPP(
            program, meta, active_arcs, current_positions, rng, route_costs, ctt1
        )

        curr_pos = current_positions[vehicle_idx]
        target_start = start_vertices[arc_idx]

        if curr_pos != target_start:
            total_costs[vehicle_idx] += od_seed[curr_pos][target_start]

        total_costs[vehicle_idx] += service_costs[arc_idx]
        current_positions[vehicle_idx] = end_vertices[arc_idx]

        _remove_active_arc(active_arcs, active_pos, arc_idx)
        _remove_active_arc(active_arcs, active_pos, reverse_index[arc_idx])

    total_fitness = 0.0
    for vehicle_idx, pos in enumerate(current_positions):
        if pos != depot:
            total_costs[vehicle_idx] += od_seed[pos][depot]
        total_fitness += total_costs[vehicle_idx]

    individual.fitness = total_fitness
    return individual


def evaluate_individual(individual, instance):
    if configure_parameters.problem == "CARP":
        return evaluate_individual_CARP(individual, instance)
    if configure_parameters.problem == "CPP":
        return evaluate_individual_CPP(individual, instance)
    raise ValueError(f"Unsupported problem type: {configure_parameters.problem}")


def _population_cache_key(instance, test_flag):
    if test_flag:
        return ("test", instance.instanceSeedList[0].seed)
    return ("train", tuple(ins.seed for ins in instance.instanceSeedList))


def evaluate_batch(ind, instance, test_flag=False):
    if test_flag:
        return evaluate_individual(ind, instance.instanceSeedList[0])

    fit_sum = 0.0
    for ins in instance.instanceSeedList:
        evaluate_individual(ind, ins)
        fit_sum += ind.fitness
    ind.fitness = fit_sum / configure_parameters.batch_learning_num
    return ind


def evaluate_population(pop, instance, test_flag=False):
    fitness_cache = {}
    cache_prefix = _population_cache_key(instance, test_flag)

    for ind in pop:
        if not test_flag and hasattr(ind, "fitness"):
            if isinstance(ind.fitness, float):
                continue
            del ind.fitness

        signature = _individual_signature(ind)
        cache_key = (cache_prefix, signature)
        cached_fitness = fitness_cache.get(cache_key)
        if cached_fitness is not None:
            ind.fitness = cached_fitness
            continue

        evaluate_batch(ind, instance, test_flag)
        fitness_cache[cache_key] = ind.fitness

    return pop
