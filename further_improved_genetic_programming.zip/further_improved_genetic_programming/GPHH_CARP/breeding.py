import random
from deap import tools
from copy import deepcopy
import configure_parameters
import utils

def breeding_population(pop, toolbox,
             seed = configure_parameters.seed,                      ##随机种子
             cxpb = configure_parameters.crossover_probability,     ##cxpb : float 交叉概率
             mutpb = configure_parameters.mutate_probability,       ##mutpb : float 变异概率
             reppb = configure_parameters.reproduct_probability,    ##reppb : float 直接复制（保持不变）的概率
             tournsize = configure_parameters.tourn_size            ##tournsize : int 锦标赛选择法的尺寸
             ):
    """
    使用 tournament selection 进行交叉 / 变异 / 保持不变 的繁殖操作
    Returns: new_pop [list] 更新后的新一代种群
    """

    ##检查pop中个体是否都已经计算过fitness了
    for ind in pop:
        if not isinstance(ind.fitness, float):
            raise ValueError("存在尚未评估的个体")

    ##检查toolbox是否提供
    if toolbox is None:
        raise ValueError("toolbox 必须提供")

    if seed is not None:
        random.seed(seed)

    assert abs(cxpb + mutpb + reppb - 1.0) < 1e-8, \
        "cxpb + mutpb + reppb must sum to 1"

    pop_size = configure_parameters.population_size
    new_pop = []
    new_pop_str = set()

    ##有限筛选精英个体
    if configure_parameters.elitism_size:

        reverse = configure_parameters.fitnessType != "MIN"
        pop.sort(key=lambda ind: ind.fitness, reverse=reverse)

        fitness_values = [ind.fitness for ind in pop]
        min_fitness = min(fitness_values)
        max_fitness = max(fitness_values)
        dur_fitness = max(max_fitness - min_fitness, 1e-12)

        elite_fitness = []  # ⭐ 单独存 fitness

        for ind in pop:
            if len(new_pop) >= configure_parameters.elitism_size:
                break

            if str(ind) in new_pop_str:
                continue

            # 多样性判定
            if elite_fitness:
                min_norm_diff = min(abs(ind.fitness - f) / dur_fitness for f in elite_fitness)
                if min_norm_diff <= configure_parameters.elitism_radius:
                    continue

            # 5️⃣ 接受该精英
            child = deepcopy(ind)
            del child.fitness

            new_pop.append(child)
            new_pop_str.add(str(child))

            elite_fitness.append(ind.fitness)

    ##传统的种群繁衍过程：
    while len(new_pop) < pop_size:

        r = random.random()

        # --------------------------------------------------
        # 1. 交叉
        # --------------------------------------------------
        if (r < cxpb) and (len(new_pop) <= pop_size - 2):


            parent1 = tools.selTournament(pop, 1, tournsize=tournsize)[0]
            parent2 = tools.selTournament(pop, 1, tournsize=tournsize)[0]

            attempt = 0
            while (str(parent1) == str(parent2)) and (attempt < configure_parameters.max_attempts_unique):
                parent1 = tools.selTournament(pop, 1, tournsize=tournsize)[0]
                parent2 = tools.selTournament(pop, 1, tournsize=tournsize)[0]
                attempt += 1

            child1 = deepcopy(parent1)
            child2 = deepcopy(parent2)

            toolbox.mate(child1, child2)

            # 保证交叉后的子代与父辈不同
            attempt = 0
            while ((str(child1) in new_pop_str or str(child2) in new_pop_str) and attempt < configure_parameters.max_attempts_unique):
                toolbox.mate(child1, child2)
                attempt += 1

            # 交叉后 fitness 失效
            del child1.fitness
            del child2.fitness

            child1 = utils.individual_height_limit(child1, configure_parameters.max_depth_mate)
            child2 = utils.individual_height_limit(child2, configure_parameters.max_depth_mate)

            new_pop.append(child1)
            new_pop.append(child2)

            new_pop_str.add(str(child1))
            new_pop_str.add(str(child2))

        # --------------------------------------------------
        # 2. 变异
        # --------------------------------------------------
        elif (r < cxpb + mutpb) and (len(new_pop) <= pop_size - 1):
            parent = tools.selTournament(pop, 1, tournsize=tournsize)[0]
            child = deepcopy(parent)

            toolbox.mutate(child)

            # 保证变异后的子代与父代不同、‘或’与新种群不同、‘或’不符合深度要求、‘且’不超过最大尝试次数
            attempt = 0
            while (str(child) in new_pop_str) and (attempt < configure_parameters.max_attempts_unique):
                toolbox.mutate(child)
                attempt += 1

            del child.fitness

            child = utils.individual_height_limit(child, configure_parameters.max_depth_mutate)
            new_pop.append(child)
            new_pop_str.add(str(child))

        # --------------------------------------------------
        # 3. 保持不变（直接复制）
        # --------------------------------------------------
        else:
            parent = tools.selTournament(pop, 1, tournsize=tournsize)[0]
            child = deepcopy(parent)

            # 与新种群不同、‘或’复不符合深度要求、‘且’不超过最大尝试次数
            attempt = 0
            while (str(child) in new_pop_str) and (attempt < configure_parameters.max_attempts_unique):
                parent = tools.selTournament(pop, 1, tournsize=tournsize)[0]
                child = deepcopy(parent)
                attempt += 1

            del child.fitness
            new_pop.append(child)
            new_pop_str.add(str(child))


    return new_pop
