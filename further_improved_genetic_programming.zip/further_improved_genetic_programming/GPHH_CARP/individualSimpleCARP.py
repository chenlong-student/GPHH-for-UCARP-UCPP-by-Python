import math
from deap import gp, creator, base
import psetHoldCARP


##使用domain knowledge用于简化individual

# ---------------------------------------------------------------------------------
# Helpers: parse a PrimitiveTree into a small AST representation
# AST node forms:
# ('const', number)
# ('var', 'ARG0')
# ('op', name, [child1, child2, ...])
# ---------------------------------------------------------------------------------

def parse_tree_nodes(nodes):
    """Parse a list(nodes) from a PrimitiveTree starting at index 0.
       Returns (ast, length) where length is number of nodes consumed."""
    # We'll use recursion with index pointer
    def parse_at(i):
        node = nodes[i]
        # Primitive (operator)
        if isinstance(node, gp.Primitive):
            name = node.name
            arity = node.arity
            children = []
            consumed = 1
            j = i + 1
            for _ in range(arity):
                child_ast, child_len = parse_at(j)
                children.append(child_ast)
                j += child_len
                consumed += child_len
            return ('op', name, children), consumed
        else:
            # Terminal
            val = node.value if hasattr(node, 'value') else node
            if isinstance(val, (int, float)):
                return ('const', float(val)), 1
            else:
                # treat anything else as variable symbol (string)
                return ('var', str(val)), 1

    ast, length = parse_at(0)
    return ast

# structural equality for AST nodes
def ast_eq(a, b):
    if a[0] != b[0]:
        return False
    if a[0] == 'const':
        return float(a[1]) == float(b[1])
    if a[0] == 'var':
        return a[1] == b[1]
    if a[1] != b[1]:
        return False
    if len(a[2]) != len(b[2]):
        return False
    return all(ast_eq(x, y) for x, y in zip(a[2], b[2]))

# evaluate operator on constant children (safe)
def eval_op_const(name, const_children):
    vals = [c[1] for c in const_children]
    try:
        if name == 'add':
            return ('const', vals[0] + vals[1])
        if name == 'sub':
            return ('const', vals[0] - vals[1])
        if name == 'mul':
            return ('const', vals[0] * vals[1])
        if name == 'div':
            return ('const', vals[0] / vals[1] if vals[1] != 0 else 1.0)
        if name == 'max':
            return ('const', vals[0] if vals[0] > vals[1] else vals[1])
        if name == 'min':
            return ('const', vals[1] if vals[0] > vals[1] else vals[0])
        if name == 'sin':
            return ('const', math.sin(vals[0]))
        if name == 'cos':
            return ('const', math.cos(vals[0]))
        if name == 'exp':
            return ('const', math.exp(vals[0]))

        if name == 'ln':
            if vals[0] == 0:
                return ('const', 1.0)
            if vals[0] < 0:
                vals[0] = -vals[0]
            return ('const', math.log(vals[0]))


        if name == 'neg':
            return ('const', -1*vals[0])

        if name == 'sqrt':
            if vals[0] < 0:
                vals[0] = -vals[0]
            return ('const', math.sqrt(vals[0]))

        if name == 'abs':
            if vals[0] < 0:
                vals[0] = -vals[0]
            return ('const', vals[0])


    except Exception:
        pass
    return None

# ---------------------------
# Simplify AST recursively
# ---------------------------
def simplify_ast(node):
    """Return simplified AST node."""

    ntype = node[0]
    if ntype in ('const', 'var'):
        return node

    _, name, children = node

    # -------- 1. Recursively simplify children --------
    simplified_children = [simplify_ast(ch) for ch in children]

    # -------- 2. Constant folding --------
    all_const = all(ch[0] == 'const' for ch in simplified_children)
    if all_const:
        res = eval_op_const(name, simplified_children)
        if res is not None:
            return res

    # -------- 3. Basic algebraic identities --------
    # sub(x,x)=0 ; div(x,x)=1 ; max(x,x)=x ; min(x,x)=x
    if len(simplified_children) == 2 and ast_eq(simplified_children[0], simplified_children[1]):
        if name == 'sub':
            return ('const', 0.0)
        if name == 'div':
            return ('const', 1.0)
        if name == 'max':
            return simplified_children[0]
        if name == 'min':
            return simplified_children[0]

    # -------- 4. Your requested special identities --------
    # A) sqrt(mul(x,x)) = abs(x)
    if name == 'sqrt' and simplified_children[0][0] == 'op' and simplified_children[0][1] == 'mul':
        c0, c1 = simplified_children[0][2]
        if ast_eq(c0, c1):  # mul(x, x)
            return ('op', 'abs', [c0]) # 返回 abs(x)

    # B) mul(sqrt(x), sqrt(x)) = x
    if name == 'mul':
        a, b = simplified_children
        if a[0] == 'op' and a[1] == 'sqrt' and b[0] == 'op' and b[1] == 'sqrt':
            if ast_eq(a[2][0], b[2][0]):
                return a[2][0]

    # C) ln(exp(x)) = x
    if name == 'ln' and simplified_children[0][0] == 'op' and simplified_children[0][1] == 'exp':
        return simplified_children[0][2][0]

    # D) exp(ln(x)) = abs(x)
    if (name == 'exp' and simplified_children[0][0] == 'op' and simplified_children[0][1] == 'ln'):
        inner_x = simplified_children[0][2][0]
        return ('op', 'abs', [inner_x])

    # E) sub(add(x,x), x) = x
    if name == 'sub':
        a, b = simplified_children
        if a[0] == 'op' and a[1] == 'add':
            c0, c1 = a[2]
            if ast_eq(c0, b) and ast_eq(c1, b):
                return b

    # -------- 5. Unary identities for constants --------
    if len(simplified_children) == 1 and simplified_children[0][0] == 'const':
        v = simplified_children[0][1]
        if name == 'sin' and v == 0:
            return ('const', 0.0)
        if name == 'cos' and v == 0:
            return ('const', 1.0)
        if name == 'exp' and v == 0:
            return ('const', 1.0)
        if name == 'ln' and v == 0:
            return ('const', 1.0)

    # -------- 6. Standard simplification rules --------
    # add
    if name == 'add':
        a, b = simplified_children
        if a == ('const', 0.0): return b
        if b == ('const', 0.0): return a

    # sub
    if name == 'sub':
        a, b = simplified_children
        if b == ('const', 0.0): return a

    # mul
    if name == 'mul':
        a, b = simplified_children
        if a == ('const', 0.0) or b == ('const', 0.0):
            return ('const', 0.0)
        if a == ('const', 1.0): return b
        if b == ('const', 1.0): return a

    # div
    if name == 'div':
        a, b = simplified_children
        if b == ('const', 1.0):
            return a

    # # -------- 7. Flatten nested add/mul (remove invalid nesting) --------
    # #   add(add(x,y), z) → add(x,y,z)
    # #   mul(mul(x,y), z) → mul(x,y,z)
    # if name in ('add', 'mul'):
    #     flat = []
    #     for ch in simplified_children:
    #         if ch[0] == 'op' and ch[1] == name:
    #             flat.extend(ch[2])  # inline children
    #         else:
    #             flat.append(ch)
    #     simplified_children = flat
    #
    #     # Remove identity elements after flattening
    #     if name == 'add':
    #         # remove 0
    #         simplified_children = [c for c in simplified_children
    #                                if not (c[0] == 'const' and c[1] == 0.0)]
    #         if len(simplified_children) == 0:
    #             return ('const', 0.0)
    #         if len(simplified_children) == 1:
    #             return simplified_children[0]
    #
    #     if name == 'mul':
    #         # any zero kills everything
    #         if any(c[0] == 'const' and c[1] == 0.0 for c in simplified_children):
    #             return ('const', 0.0)
    #         # remove 1
    #         simplified_children = [c for c in simplified_children
    #                                if not (c[0] == 'const' and c[1] == 1.0)]
    #         if len(simplified_children) == 0:
    #             return ('const', 1.0)
    #         if len(simplified_children) == 1:
    #             return simplified_children[0]
    #
    #     return ('op', name, simplified_children)

    # -------- 8. No special rule matched → return structured node --------
    return ('op', name, simplified_children)


# ---------------------------
# Convert AST back to expression string for gp.PrimitiveTree.from_string
# Use function names as in pset (e.g., plus, sub, sin, cos, exp, ln, max, min)
# ---------------------------
def ast_to_string(ast):
    if ast[0] == 'const':
        # represent constant without quotes
        v = ast[1]
        # if integer-like, keep as int
        if abs(v - int(v)) < 1e-12:
            return str(int(v))
        else:
            return repr(float(v))
    if ast[0] == 'var':
        return ast[1]  # e.g. ARG0
    # op
    name = ast[1]
    child_strs = [ast_to_string(ch) for ch in ast[2]]
    return f"{name}(" + ", ".join(child_strs) + ")"

# ---------------------------
# Main API: simplify a DEAP Individual and return a DEAP Individual
# ---------------------------
def simplify_individual_keep_type(individual, pset = psetHoldCARP.psetHold()):
    """
    individual: a deap.gp.PrimitiveTree (Individual)
    pset: the PrimitiveSet used to build the tree (for from_string)
    returns: a new creator.Individual (PrimitiveTree) simplified
    """

    nodes = list(individual)
    ast = parse_tree_nodes(nodes)
    simp = simplify_ast(ast)
    expr_str = ast_to_string(simp)

    # rebuild a PrimitiveTree from string using pset
    new_tree = gp.PrimitiveTree.from_string(expr_str, pset)
    # wrap as Individual (assume creator.Individual exists)
    return creator.Individual(new_tree)




# ---------------------------
# Example quick test if run directly
# ---------------------------
if __name__ == "__main__":
    # create DEAP environment for standalone testing
    creator.create("FitnessMin", base.Fitness, weights=(-1.0,))
    creator.create("Individual", gp.PrimitiveTree, fitness=creator.FitnessMin)

    pset = psetHoldCARP.psetHold()

    # expr_str = "sqrt(mul(ARG0, ARG0))"
    # expr_str = "add(exp(min(min(max(min(x0, mul(mul(sub(x0, 0.18246333349639965), abs(2.427080333831114)), abs(abs(2.6744604665153577)))), sub(ln(add(add(x0, 2.5978728087788694), x0)), add(x0, 2.9982348967708834))), 2.6744604665153577), 2.9982348967708834)), 2.6744604665153577)"
    # expr_str = "add(1, add(x0, 2.5978728087788694))"
    expr_str = "add(sub(add(CFH, ERC), max(SC, CFD)), sub(add(SC, ERC), sub(CTD, CTD)))"

    ind = gp.PrimitiveTree.from_string(expr_str, pset)
    ind = creator.Individual(ind)


    print("Original:", ind)
    new_ind = simplify_individual_keep_type(ind, pset)
    print("Simplified:", new_ind)




