from deap import tools, gp
import psetHoldCARP
import configure_parameters
import gp_extension

def register_breeding_ops(toolbox):
    """选择、交叉、变异操作的注册"""

    pset = psetHoldCARP.psetHold()

    if not hasattr(toolbox, "select"):
        toolbox.register("select", getattr(tools, configure_parameters.selection_way), tournsize = configure_parameters.tourn_size)

    toolbox.register("mate", gp.cxOnePoint)

    toolbox.register("expr_mut", gp.genFull, min_ = configure_parameters.min_depth_new_subtree, max_ = configure_parameters.max_depth_new_subtree)
    toolbox.register("mutate", gp.mutUniform, expr = toolbox.expr_mut, pset = pset)

    # 限制树的最大深度，防止爆炸增长
    # 同样使用lambda封装: key=lambda ind: ind.height
    toolbox.decorate("mate", gp.staticLimit(key=len, max_value=configure_parameters.max_depth_mate))
    toolbox.decorate("mutate", gp.staticLimit(key=len, max_value=configure_parameters.max_depth_mutate))

