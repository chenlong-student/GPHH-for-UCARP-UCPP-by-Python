import random

#############################################################################
import populationInitializationCARP
import optimizationTargetCARP
import breedingProcessCARP
import fitnessEvaluationCARP

from toolBoxCARP import toolbox
#############################################################################


def toolbox_init(seed = None):

    random.seed(seed)

    # ---------------------------------------
    # 1. 创建 Fitness 与 Individual 类型
    # ---------------------------------------
    optimizationTargetCARP.create_fitness_and_individual()

    # ---------------------------------------
    # 2. 注册 种群初始化
    # ---------------------------------------
    populationInitializationCARP.register_population()

    # ---------------------------------------
    # 3. 注册 选择/交叉/变异操作
    # ---------------------------------------
    breedingProcessCARP.register_breeding_ops(toolbox)

    # ---------------------------------------
    # 4. 注册适应度函数
    # ---------------------------------------
    fitnessEvaluationCARP.register_fitness_function()

    return toolbox

if __name__ == "__main__":
    toolbox = toolbox_init()
    pop = toolbox.population(n=100)

    ind1 = pop[2]
    ind, = toolbox.mutate(ind1)
    print(ind1)
    print(ind)

    a = 1






