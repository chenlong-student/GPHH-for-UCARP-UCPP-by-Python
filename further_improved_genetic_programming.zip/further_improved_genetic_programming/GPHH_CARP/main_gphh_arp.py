import os
import sys
import time
import datetime
from copy import deepcopy
import pandas as pd

from experimentLogger import ExperimentLogger
import toolboxRegister
import configure_parameters
import breeding
import evaluate
import utils
import Instance


# =====================================================
# 主程序
# =====================================================
if __name__ == "__main__":

    # ========== 1. 实验信息 ==========
    seed = configure_parameters.seed

    instance_path = configure_parameters.data_path
    instance_name = os.path.splitext(os.path.basename(instance_path))[0]
    timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")

    # 日志目录
    log_dir = "experiment_logs"
    os.makedirs(log_dir, exist_ok=True)

    log_file = os.path.join(
        log_dir,
        f"{instance_name}_seed{seed}_{timestamp}.txt"
    )

    # ========== 2. 启动实验日志 ==========
    logger = ExperimentLogger(log_file)
    sys.stdout = logger
    print("===================================================")
    print(f"GPHH-{configure_parameters.problem} Experiment Start")
    print(f"Instance     : {instance_name}")
    print(f"Instance path: {instance_path}")
    print(f"Seed         : {seed}")
    print("===================================================\n")

    ##now here we go
    s = 0

    # ========== 3. 加载算例 ==========
    instance = Instance.Instance(instance_path, s)

    # ========== 4. Toolbox 初始化 ==========
    toolbox = toolboxRegister.toolbox_init(seed)

    # ========== 5. 种群初始化 ==========
    pop = toolbox.population(n=configure_parameters.population_size)

    # 移除种群中的相同个体，再用新生成的替代（新生成的个体有一个最大尝试次数限制）
    pop = utils.remove_duplicate_and_refill(pop, toolbox)

    # ========== 6. 初始适应度评估 ==========
    pop_evaluated = evaluate.evaluate_population(pop, instance, test_flag = False)

    # ========== 7. 收集每代最优个体 ==========
    best_ind_pop = []

    # ===== 新增：训练 & 测试结果记录容器 =====
    train_records = []
    test_records = []

    while s < configure_parameters.gen:

        ##record the start time
        start_time0 = time.time()

        best_ind = utils.find_best_ind(pop_evaluated)

        print()
        print(f"================ Train Process in The {s}-th Generation =================")
        print("Best individual:")
        print(best_ind)
        print("Best fitness:", best_ind.fitness)


        # 记录训练结果
        train_records.append({
            "fitness_value": best_ind.fitness,
            "height_value": best_ind.height,
            "individual": str(best_ind)
        })

        # new_pop = breeding.breeding_population(pop_evaluated, toolbox)
        ##breeding
        if utils.check_best_ind_same(best_ind_pop, s) == False:
            new_pop = breeding.breeding_population(pop_evaluated, toolbox)
        else:

            ##reset a new population
            pop = toolbox.population(n=configure_parameters.population_size)


            new_pop = deepcopy(pop)
            new_pop = utils.remove_duplicate_and_refill(new_pop, toolbox)
            for ind in new_pop:
                if hasattr(ind, "fitness"):
                    if isinstance(ind.fitness, float):
                        del ind.fitness



        ##reset instance(s) by seed
        instance.resetSeedInstance(seed, configure_parameters, s + 1)
        print(f'The population size of the new_pop is {len(new_pop)}')
        s1 = time.time()
        pop_evaluated = evaluate.evaluate_population(new_pop, instance, test_flag = True)
        s2 = time.time()
        ss = 0
        for iii in range(len(pop_evaluated)):
            ss = ss + pop_evaluated[iii].height
        ss = ss / len(pop_evaluated)
        print(f'The average high of the pop_evaluated is {ss}')
        print(f'The population size of the pop_evaluated is {len(pop_evaluated)}')
        print(f'the evoluation time is {s2 - s1}')

        end_time0 = time.time()
        print(f"running duration:{end_time0 - start_time0}")

        best_ind_pop.append(best_ind)
        s += 1


    # ========== 8. 测试阶段 ==========
    print("\n================ Testing Process =================\n")
    instance.resetSeedInstance(seed, configure_parameters, 1 + configure_parameters.gen * 2)
    evaluate.evaluate_population(best_ind_pop, instance, test_flag = True)

    for i, best_ind in enumerate(best_ind_pop):
        print(f"---------- Best individual from the {i}-th generation ----------")
        print(best_ind)
        print("Test fitness:", best_ind.fitness)
        print()

        # 记录测试结果
        test_records.append({
            "fitness_value": best_ind.fitness,
            "height_value": best_ind.height,
            "individual": str(best_ind)
        })

    # ========== 8.5 保存训练 & 测试结果到 Excel ==========
    train_df = pd.DataFrame(train_records)
    test_df = pd.DataFrame(test_records)

    train_excel_path = os.path.join(
        log_dir,
        f"{instance_name}_seed{seed}_{timestamp}_train_results_{configure_parameters.problem}.xlsx"
    )

    test_excel_path = os.path.join(
        log_dir,
        f"{instance_name}_seed{seed}_{timestamp}_test_results_{configure_parameters.problem}.xlsx"
    )

    train_df.to_excel(train_excel_path, index=False)
    test_df.to_excel(test_excel_path, index=False)

    # ========== 9. 关闭日志 ==========
    sys.stdout = sys.__stdout__
    logger.close()

    print(f"Experiment log saved to: {log_file}")
