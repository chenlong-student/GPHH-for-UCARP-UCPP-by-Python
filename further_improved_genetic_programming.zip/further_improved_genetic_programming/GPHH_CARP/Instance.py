import os
import re
import math
import heapq
import random
from copy import deepcopy

import configure_parameters
from Arc import Arc
from Vehicle import Vehicle


class Instance:
    def __init__(self, file_path, gen, seed = configure_parameters.seed):
        # 1. 加载文本
        instance_text = self.load_instance_text(file_path)

        # 2. 解析逻辑 (确保返回 dict)
        if configure_parameters.problem == "CPP":
            instance = self.parse_instance_CPP(instance_text)
        elif configure_parameters.problem == "RPP":
            instance = self.parse_instance_RPP(instance_text)
        elif configure_parameters.problem == "kRPP":
            instance = self.parse_instance_kRPP(instance_text)
        elif configure_parameters.problem == "CARP":
            instance = self.parse_instance_CARP(instance_text)

        self.instance = instance.copy()

        # 3. 基础属性赋值 (保持原名)
        self.vertices = instance["vertices"]
        self.vehiculos = instance["vehiculos"]
        self.capacidad = instance["capacidad"]
        self.deposito = instance["deposito"]

        # 4. 边和车辆 (保持原名)
        self.originalEdges = instance["edges"]
        self.vehicles = [Vehicle(vehicle_count=self.vehiculos, capacity=self.capacidad, start_depot=self.deposito) for _ in range(self.vehiculos)]
        self.positions = [self.deposito] * self.vehiculos

        # 5. 区分弧段
        self.original_requiredArc = [arc for arc in self.originalEdges if arc.demanda > 0]
        self.original_noRequiredArc = [arc for arc in self.originalEdges if arc.demanda == 0]

        # 6. 计算路网
        self.get_originalGraph()

        # 7. 计算随机种子样本
        self.seedInstance(seed, configure_parameters, gen)


    def load_instance_text(self, file_path: str) -> str:
        if not os.path.exists(file_path):
            raise FileNotFoundError(f"文件不存在: {file_path}")
        with open(file_path, 'r', encoding='utf-8') as f:
            return f.read()


    def parse_instance_CPP(self, text: str):
        """完全保留你原本的解析逻辑"""
        vertices = int(re.search(r"VERTICES\s*:\s*(\d+)", text).group(1))
        vehiculos = int(re.search(r"VEHICULOS\s*:\s*(\d+)", text).group(1))
        capacidad = math.inf
        deposito = int(re.search(r"DEPOSITO\s*:\s*(\d+)", text).group(1))

        edges = []
        has_no_req = "LISTA_ARISTAS_NOREQ" in text

        # 必需弧提取
        if has_no_req:
            req_match = re.search(r"LISTA_ARISTAS_REQ\s*:(.*?)(?=\s*LISTA_ARISTAS_NOREQ\s*:)", text, re.S)
        else:
            req_match = re.search(r"LISTA_ARISTAS_REQ\s*:(.*?)(?=\s*DEPOSITO\s*:)", text, re.S)

        if req_match:
            req_block = req_match.group(1)
            required_pattern = re.compile(r"\(\s*(\d+)\s*,\s*(\d+)\)\s*coste\s*(\d+)")
            for m in required_pattern.finditer(req_block):
                u, v, coste = map(int, m.groups())
                demanda = 1.0
                arc_fwd = Arc(u, v, demanda, coste)
                arc_rev = Arc(v, u, demanda, coste)
                arc_fwd.set_reverse(arc_rev)
                arc_rev.set_reverse(arc_fwd)
                edges.append(arc_fwd)
                edges.append(arc_rev)

        # 非必需弧提取
        if has_no_req:
            no_req_match = re.search(r"LISTA_ARISTAS_NOREQ\s*:(.*?)(?=\s*DEPOSITO\s*:)", text, re.S)
            if no_req_match:
                no_req_block = no_req_match.group(1)
                no_required_pattern = re.compile(r"\(\s*(\d+)\s*,\s*(\d+)\)\s*coste\s*(\d+)")
                for m in no_required_pattern.finditer(no_req_block):
                    u, v, coste = map(int, m.groups())
                    arc_fwd = Arc(u, v, 0, coste)
                    arc_rev = Arc(v, u, 0, coste)
                    arc_fwd.set_reverse(arc_rev)
                    arc_rev.set_reverse(arc_fwd)
                    edges.append(arc_fwd)
                    edges.append(arc_rev)

        return {
            "vertices": vertices, "vehiculos": vehiculos,
            "capacidad": capacidad, "deposito": deposito, "edges": edges
        }

    def parse_instance_CARP(self, text: str):
        """完全保留你原本的解析逻辑"""
        vertices = int(re.search(r"VERTICES\s*:\s*(\d+)", text).group(1))
        vehiculos = int(re.search(r"VEHICULOS\s*:\s*(\d+)", text).group(1))
        capacidad = int(re.search(r"CAPACIDAD\s*:\s*(\d+)", text).group(1))
        deposito = int(re.search(r"DEPOSITO\s*:\s*(\d+)", text).group(1))

        edges = []
        has_no_req = "LISTA_ARISTAS_NOREQ" in text

        # 必需弧提取
        if has_no_req:
            req_match = re.search(r"LISTA_ARISTAS_REQ\s*:(.*?)(?=\s*LISTA_ARISTAS_NOREQ\s*:)", text, re.S)
        else:
            req_match = re.search(r"LISTA_ARISTAS_REQ\s*:(.*?)(?=\s*DEPOSITO\s*:)", text, re.S)

        if req_match:
            req_block = req_match.group(1)
            required_pattern = re.compile(r"\(\s*(\d+)\s*,\s*(\d+)\)\s*coste\s*(\d+)\s*demanda\s*(\d+)")
            for m in required_pattern.finditer(req_block):
                u, v, coste, demanda = map(int, m.groups())
                arc_fwd = Arc(u, v, demanda, coste)
                arc_rev = Arc(v, u, demanda, coste)
                arc_fwd.set_reverse(arc_rev)
                arc_rev.set_reverse(arc_fwd)
                edges.append(arc_fwd)
                edges.append(arc_rev)

        # 非必需弧提取
        if has_no_req:
            no_req_match = re.search(r"LISTA_ARISTAS_NOREQ\s*:(.*?)(?=\s*DEPOSITO\s*:)", text, re.S)
            if no_req_match:
                no_req_block = no_req_match.group(1)
                no_required_pattern = re.compile(r"\(\s*(\d+)\s*,\s*(\d+)\)\s*coste\s*(\d+)")
                for m in no_required_pattern.finditer(no_req_block):
                    u, v, coste = map(int, m.groups())
                    arc_fwd = Arc(u, v, 0, coste)
                    arc_rev = Arc(v, u, 0, coste)
                    arc_fwd.set_reverse(arc_rev)
                    arc_rev.set_reverse(arc_fwd)
                    edges.append(arc_fwd)
                    edges.append(arc_rev)

        return {
            "vertices": vertices, "vehiculos": vehiculos,
            "capacidad": capacidad, "deposito": deposito, "edges": edges
        }

    def parse_instance_RPP(self, text: str):
        """完全保留你原本的解析逻辑"""
        vertices = int(re.search(r"VERTICES\s*:\s*(\d+)", text).group(1))
        vehiculos = int(re.search(r"VEHICULOS\s*:\s*(\d+)", text).group(1))
        capacidad = math.inf
        deposito = int(re.search(r"DEPOSITO\s*:\s*(\d+)", text).group(1))

        edges = []
        has_no_req = "LISTA_ARISTAS_NOREQ" in text

        # 必需弧提取
        if has_no_req:
            req_match = re.search(r"LISTA_ARISTAS_REQ\s*:(.*?)(?=\s*LISTA_ARISTAS_NOREQ\s*:)", text, re.S)
        else:
            req_match = re.search(r"LISTA_ARISTAS_REQ\s*:(.*?)(?=\s*DEPOSITO\s*:)", text, re.S)

        if req_match:
            req_block = req_match.group(1)
            required_pattern = re.compile(r"\(\s*(\d+)\s*,\s*(\d+)\)\s*coste\s*(\d+)")
            for m in required_pattern.finditer(req_block):
                u, v, coste = map(int, m.groups())
                demanda = 1.0
                arc_fwd = Arc(u, v, demanda, coste)
                arc_rev = Arc(v, u, demanda, coste)
                arc_fwd.set_reverse(arc_rev)
                arc_rev.set_reverse(arc_fwd)
                edges.append(arc_fwd)
                edges.append(arc_rev)

        # 非必需弧提取
        if has_no_req:
            no_req_match = re.search(r"LISTA_ARISTAS_NOREQ\s*:(.*?)(?=\s*DEPOSITO\s*:)", text, re.S)
            if no_req_match:
                no_req_block = no_req_match.group(1)
                no_required_pattern = re.compile(r"\(\s*(\d+)\s*,\s*(\d+)\)\s*coste\s*(\d+)")
                for m in no_required_pattern.finditer(no_req_block):
                    u, v, coste = map(int, m.groups())
                    arc_fwd = Arc(u, v, 0, coste)
                    arc_rev = Arc(v, u, 0, coste)
                    arc_fwd.set_reverse(arc_rev)
                    arc_rev.set_reverse(arc_fwd)
                    edges.append(arc_fwd)
                    edges.append(arc_rev)

        return {
            "vertices": vertices, "vehiculos": vehiculos,
            "capacidad": capacidad, "deposito": deposito, "edges": edges
        }

    def parse_instance_kRPP(self, text: str):
        """完全保留你原本的解析逻辑"""
        vertices = int(re.search(r"VERTICES\s*:\s*(\d+)", text).group(1))
        vehiculos = int(re.search(r"VEHICULOS\s*:\s*(\d+)", text).group(1))
        capacidad = math.inf
        deposito = int(re.search(r"DEPOSITO\s*:\s*(\d+)", text).group(1))

        edges = []
        has_no_req = "LISTA_ARISTAS_NOREQ" in text

        # 必需弧提取
        if has_no_req:
            req_match = re.search(r"LISTA_ARISTAS_REQ\s*:(.*?)(?=\s*LISTA_ARISTAS_NOREQ\s*:)", text, re.S)
        else:
            req_match = re.search(r"LISTA_ARISTAS_REQ\s*:(.*?)(?=\s*DEPOSITO\s*:)", text, re.S)

        if req_match:
            req_block = req_match.group(1)
            required_pattern = re.compile(r"\(\s*(\d+)\s*,\s*(\d+)\)\s*coste\s*(\d+)")
            for m in required_pattern.finditer(req_block):
                u, v, coste = map(int, m.groups())
                demanda = 1.0
                arc_fwd = Arc(u, v, demanda, coste)
                arc_rev = Arc(v, u, demanda, coste)
                arc_fwd.set_reverse(arc_rev)
                arc_rev.set_reverse(arc_fwd)
                edges.append(arc_fwd)
                edges.append(arc_rev)

        # 非必需弧提取
        if has_no_req:
            no_req_match = re.search(r"LISTA_ARISTAS_NOREQ\s*:(.*?)(?=\s*DEPOSITO\s*:)", text, re.S)
            if no_req_match:
                no_req_block = no_req_match.group(1)
                no_required_pattern = re.compile(r"\(\s*(\d+)\s*,\s*(\d+)\)\s*coste\s*(\d+)")
                for m in no_required_pattern.finditer(no_req_block):
                    u, v, coste = map(int, m.groups())
                    arc_fwd = Arc(u, v, 0, coste)
                    arc_rev = Arc(v, u, 0, coste)
                    arc_fwd.set_reverse(arc_rev)
                    arc_rev.set_reverse(arc_fwd)
                    edges.append(arc_fwd)
                    edges.append(arc_rev)

        return {
            "vertices": vertices, "vehiculos": vehiculos,
            "capacidad": capacidad, "deposito": deposito, "edges": edges
        }


    def dijkstra_with_path(self, start_node, vertices, adj):
        distances = [math.inf] * (vertices + 1)
        parents = [None] * (vertices + 1)
        distances[start_node] = 0
        pq = [(0, start_node)]
        while pq:
            curr_dist, u = heapq.heappop(pq)
            if curr_dist > distances[u]: continue
            for v, cost in adj[u]:
                if curr_dist + cost < distances[v]:
                    distances[v] = curr_dist + cost
                    parents[v] = u
                    heapq.heappush(pq, (distances[v], v))
        return distances, parents

    def get_originalGraph(self):
        size = self.vertices + 1
        self.originalGraph = [[math.inf] * size for _ in range(size)]
        self.originalGraphConnected = [[math.inf] * size for _ in range(size)]
        self.originalParentMatrix = [None] * size
        self.originalPathMatrix = [[[] for _ in range(size)] for _ in range(size)]

        adj = [[] for _ in range(size)]
        for arc in self.originalEdges:
            adj[arc.start_vertex].append((arc.end_vertex, arc.coste))
            self.originalGraph[arc.start_vertex][arc.end_vertex] = arc.coste

        for i in range(1, size):
            dist, parents = self.dijkstra_with_path(i, self.vertices, adj)
            self.originalGraphConnected[i] = dist
            self.originalParentMatrix[i] = parents
            for j in range(1, size):
                if dist[j] != math.inf:
                    path, curr = [], j
                    while curr is not None:
                        path.append(curr)
                        curr = parents[curr]
                    self.originalPathMatrix[i][j] = path[::-1]

    def seedInstance(self, seed, configure_parameters, gen):
        rng = random.Random(seed)
        pop_size = configure_parameters.population_size
        batch_num = configure_parameters.batch_learning_num
        seedlist = [rng.randint(1 + gen * pop_size * batch_num, (1 + gen) * pop_size * batch_num) for _ in range(batch_num)]

        self.instanceSeedList = []
        for seedSample in seedlist:
            # 使用包装类，既保证变量名一致，又避免深拷贝父类矩阵导致的适应度错误
            sample = SeededSample(self, seedSample)
            self.instanceSeedList.append(sample)

    def resetSeedInstance(self, seed, configure_parameters, gen):
        self.seedInstance(seed, configure_parameters, gen)


class SeededSample:
    """包装类，确保 instanceSeedList[i] 拥有所有 Instance 属性和变量名"""

    def __init__(self, parent, seed):
        self.seed = seed
        self.vertices = parent.vertices
        self.vehiculos = parent.vehiculos
        self.capacidad = parent.capacidad
        self.deposito = parent.deposito
        self.originalGraphConnected = parent.originalGraphConnected

        # 关键：独立备份车辆和位置，防止下游计算干扰导致适应度异常
        self.vehicles = deepcopy(parent.vehicles)
        self.positions = list(parent.positions)

        # 随机化边并区分 (保持原名)
        self.seedEdges = [deepcopy(arc) for arc in parent.originalEdges]
        for arc in self.seedEdges:
            arc.randomize(seed)

        self.seed_requiredArc = [arc for arc in self.seedEdges if arc.demanda > 0]
        self.seed_noRequiredArc = [arc for arc in self.seedEdges if arc.demanda == 0]

        # 重新计算该种子下的路网 (保持原名)
        size = self.vertices + 1
        self.seedGraph = [[math.inf] * size for _ in range(size)]
        self.seedGraphConnected = [[math.inf] * size for _ in range(size)]
        self.seedPathMatrix = [[[] for _ in range(size)] for _ in range(size)]

        adj = [[] for _ in range(size)]
        for arc in self.seedEdges:
            adj[arc.start_vertex].append((arc.end_vertex, arc.coste))
            self.seedGraph[arc.start_vertex][arc.end_vertex] = arc.coste

        for i in range(1, size):
            dist, parents = parent.dijkstra_with_path(i, self.vertices, adj)
            self.seedGraphConnected[i] = dist
            for j in range(1, size):
                if dist[j] != math.inf:
                    path, curr = [], j
                    while curr is not None:
                        path.append(curr)
                        curr = parents[curr]
                    self.seedPathMatrix[i][j] = path[::-1]