from deap import creator, tools, gp
import psetHoldCARP
from toolBoxCARP import toolbox
import configure_parameters

def register_population(toolbox = toolbox):
    """注册个体和种群初始化操作"""

    pset = psetHoldCARP.psetHold()

    # gp.genHalfAndHalf <==> getattr(gp, configure_parameters.population_generation_way)
    toolbox.register("expr", getattr(gp, configure_parameters.population_generation_way), pset=pset, min_=configure_parameters.min_depth_initial, max_=configure_parameters.max_depth_initial)
    toolbox.register("individual", tools.initIterate, creator.Individual, toolbox.expr)
    toolbox.register("population", tools.initRepeat, list, toolbox.individual)

