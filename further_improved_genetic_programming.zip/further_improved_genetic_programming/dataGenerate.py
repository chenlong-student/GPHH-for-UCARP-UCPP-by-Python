import numpy as np

def generate_dataset(n=50):
    """示例数据： y = x^2 + 2x + 3"""
    X = np.linspace(-3, 3, n)
    y = X**2 + 2*X + 3
    return X, y
